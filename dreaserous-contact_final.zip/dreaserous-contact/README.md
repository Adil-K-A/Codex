# Dreaserous Contact Project

This is the full project for the Dreaserous Productions Contact Page Challenge.

## Structure
- backend/ : Express.js server + SQLite database
- frontend/ : Angular project (with contact form + FAQ components)
- README.md : Instructions

## How to Run (with Codespaces or locally)

### Backend
```bash
cd backend
npm install
node server.js
```
Runs on port 3000.

### Frontend
```bash
cd frontend
npm install
ng serve --proxy-config proxy.conf.json
```
Runs on port 4200.

### Access
Open http://localhost:4200 (or Codespaces port preview).

## Features
- Contact form with validation (name, email, subject, message)
- FAQ section (expand/collapse + search)
- Mobile responsive
- Dark mode toggle

## Submission Checklist
- Include backend/, frontend/, database.db, README.md
- Add demo video separately
