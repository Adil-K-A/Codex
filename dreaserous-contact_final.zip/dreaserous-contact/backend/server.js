const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser');

const DB_FILE = path.join(__dirname, 'database.db');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Initialize DB
const db = new sqlite3.Database(DB_FILE, (err) => {
  if (err) {
    console.error('Could not open DB', err);
  } else {
    console.log('Connected to SQLite DB:', DB_FILE);
  }
});

// Create tables if not exist
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS contacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL,
    subject TEXT,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL
  );`);
  db.run(`CREATE TABLE IF NOT EXISTS faqs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    display_order INTEGER DEFAULT 0
  );`);
});

// API Endpoints

// Health
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Get FAQs
app.get('/api/faqs', (req, res) => {
  db.all('SELECT id, question, answer, display_order FROM faqs ORDER BY display_order ASC, id ASC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Get contacts (admin)
app.get('/api/contacts', (req, res) => {
  db.all('SELECT id, name, email, subject, message, created_at FROM contacts ORDER BY created_at DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Post contact
app.post('/api/contacts', (req, res) => {
  const { name, email, subject, message } = req.body || {};
  if (!name || !email || !message) {
    return res.status(400).json({ error: 'name, email and message are required' });
  }
  const created_at = new Date().toISOString();
  const stmt = db.prepare('INSERT INTO contacts (name, email, subject, message, created_at) VALUES (?,?,?,?,?)');
  stmt.run(name, email, subject || '', message, created_at, function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true, id: this.lastID, created_at });
  });
});

// Serve static frontend (optional)
app.use(express.static(path.join(__dirname, '..', 'frontend')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});