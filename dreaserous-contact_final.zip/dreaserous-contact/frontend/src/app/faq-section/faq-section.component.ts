import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-faq-section',
  templateUrl: './faq-section.component.html',
  styleUrls: ['./faq-section.component.css']
})
export class FaqSectionComponent implements OnInit {
  faqs: any[] = [];
  filtered: any[] = [];
  query = '';

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.loadFaqs();
  }

  async loadFaqs() {
    try {
      this.faqs = await this.api.getFaqs().toPromise();
      this.filtered = [...this.faqs];
    } catch (err) {
      console.error(err);
    }
  }

  onSearch() {
    const q = this.query.trim().toLowerCase();
    if (!q) { this.filtered = [...this.faqs]; return; }
    this.filtered = this.faqs.filter(f => (f.question + f.answer).toLowerCase().includes(q));
  }

  toggle(item: any) {
    item.open = !item.open;
  }
}