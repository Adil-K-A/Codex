import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private base = '';

  constructor(private http: HttpClient) {}

  getFaqs(): Observable<any> {
    return this.http.get('/api/faqs');
  }

  postContact(payload: any): Observable<any> {
    return this.http.post('/api/contacts', payload);
  }

  getContacts(): Observable<any> {
    return this.http.get('/api/contacts');
  }
}