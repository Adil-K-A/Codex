import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {
  form = this.fb.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    subject: ['General'],
    message: ['', [Validators.required, Validators.minLength(10)]]
  });
  status = '';
  sending = false;

  constructor(private fb: FormBuilder, private api: ApiService) {}

  ngOnInit(): void {}

  async onSubmit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.sending = true;
    this.status = 'Sending...';
    try {
      const res: any = await this.api.postContact(this.form.value).toPromise();
      this.form.reset({ subject: 'General' });
      this.status = 'Message sent successfully! 🎉';
    } catch (err) {
      console.error(err);
      this.status = 'Failed to send message. Please try again.';
    } finally {
      this.sending = false;
      setTimeout(()=> this.status = '', 5000);
    }
  }
}